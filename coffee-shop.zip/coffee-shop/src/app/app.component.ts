import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    title(title: any) {
      throw new Error('Method not implemented.');
    }
    coffees: any[] = [];

    constructor(private http: HttpClient) {
        this.fetchCoffees();
    }

    fetchCoffees() {
        this.http.get('https://api.sampleapis.com/coffee/hot')
            .subscribe((response: any) => {
                this.coffees = response;
            });
    }
}
