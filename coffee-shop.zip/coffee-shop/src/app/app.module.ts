import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

@NgModule({
  declarations: [
   
  ],
  imports: [
    BrowserModule,
    
  ],
  bootstrap: []
})
export class AppModule { }
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        const cloned = req.clone({
            setHeaders: {
                Authorization: `Bearer my-token`
            }
        });
        return next.handle(cloned);
    }
}
provideHttpClient(withInterceptorsFromDi()) ;[
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ]
  